package com.test.masterwebview

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find WebView
        val myWebView: WebView = findViewById(R.id.webview_id)

        // Enable JavaScript
        val webSettings: WebSettings = myWebView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true  // Enable Local Storage
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true

        // Ensure WebView opens links inside the app
        myWebView.webViewClient = WebViewClient()

        // Load website
        myWebView.loadUrl("20.30.1.143:3000")
    }
}
